#ifndef SHIM_SHELL_H
#define SHIM_SHELL_H

EFI_STATUS
argsplit(EFI_HANDLE image, int *argc, CHAR16*** ARGV);

#endif /* SHIM_SHELL_H */
