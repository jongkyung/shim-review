#ifndef _SHIM_VERSION_H
#define _SHIM_VERSION_H 1

#include <efi.h>

extern CHAR8 shim_version[];

#endif /* SHIM_VERSION_H */
