#define PLATFORM  "UEFI"
#define DATE      "Tues Mar 21 01:23:45 PDT 2017"
