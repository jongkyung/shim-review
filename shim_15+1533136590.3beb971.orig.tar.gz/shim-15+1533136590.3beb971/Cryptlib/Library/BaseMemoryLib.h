CHAR8 *ScanMem8(CHAR8 *str, UINTN count, CHAR8 ch);
